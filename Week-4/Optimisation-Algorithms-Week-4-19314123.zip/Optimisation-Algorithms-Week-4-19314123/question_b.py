import numpy as np
from matplotlib import pyplot as plt
from question_a import rms_prop, get_derivative_of_functions, heavy_ball, adam


def part_b_i(function, array_of_lambda_functions, x, number_of_function):
    iterations = 200
    list_of_a_0 = [0.001, 0.01, 0.1]
    list_of_b = [0.25, 0.9]
    list_of_iterations = list(range(iterations + 1))
    plot_legend = []
    colors = ['red', 'green', 'blue', 'orange', 'purple', 'cyan']
    index_of_color = 0
    for a_0 in list_of_a_0:
        for b in list_of_b:
            x_param_values_at_each_iteration, corresponding_values_of_function, steps_at_each_iteration = rms_prop(
                function, array_of_lambda_functions, x, [a_0, b], iterations)
            # function values vs iterations
            plt.figure(1)
            plt.plot(list_of_iterations, corresponding_values_of_function, color=colors[index_of_color])
            # x step size vs iterations
            step_size_x = [step[0] for step in steps_at_each_iteration]
            plt.figure(2)
            plt.plot(list_of_iterations, step_size_x, color=colors[index_of_color])
            # y step size vs iterations
            step_size_y = [step[1] for step in steps_at_each_iteration]
            plt.figure(3)
            plt.plot(list_of_iterations, step_size_y, color=colors[index_of_color])
            plot_legend.append(f'alpha_0={a_0}, beta={b}')
            print(f'final value = {corresponding_values_of_function[-1]} when alpha_0 = {a_0}, beta = {b}')
            index_of_color += 1
    plt.figure(1)
    # Set y-axis limits to fit as much as possible
    if number_of_function == 1:
        plt.ylim([0, 100])
    plt.ylabel(f"f_{number_of_function}(x,y)")
    plt.xlabel("Iterations")
    plt.title(f"f_{number_of_function}(x,y) gradient descent with RMSProp")
    plt.legend(plot_legend)
    plt.savefig(f"plots/part_b/part_i_f_{number_of_function}")
    plt.figure(2)
    plt.ylabel("step size of x")
    plt.xlabel("Iterations")
    plt.title(f"f_{number_of_function} with step size of x")
    plt.savefig(f"plots/part_b/part_i_f_{number_of_function}_step_x")
    plt.figure(3)
    plt.ylabel("step size of y")
    plt.xlabel("Iterations")
    plt.title(f"Step size of y for f_{number_of_function}")
    plt.savefig(f"plots/part_b/part_i_f_{number_of_function}_step_y")
    plt.show()


def part_b_ii(function, array_of_lambda_functions, x, number_of_function):
    iterations = 200
    list_of_a = [0.01, 0.1, 1]
    list_of_b = [0.25, 0.9]
    list_of_iterations = list(range(iterations + 1))
    plot_legend = []
    colors = ['red', 'green', 'blue', 'orange', 'purple', 'cyan']
    index_of_color = 0
    for a in list_of_a:
        for b in list_of_b:
            x_param_values_at_each_iteration, corresponding_values_of_function, steps_at_each_iteration = heavy_ball(
                function, array_of_lambda_functions, x, [a, b], iterations)
            plt.plot(list_of_iterations, corresponding_values_of_function, color=colors[index_of_color])
            plot_legend.append(f"alpha={a}, beta={b}")
            print(f'final value = {corresponding_values_of_function[-1]} when alpha = {a}, beta = {b}')
            index_of_color += 1
    plt.ylim([0, 30])
    # Set y-axis limits to fit as much as possible
    if number_of_function == 1:
        plt.ylim([0, 200])
    plt.ylabel(f"f_{number_of_function}(x,y)")
    plt.xlabel("Iterations")
    plt.title(f"f_{number_of_function}(x,y) gradient descent with Heavy Ball")
    plt.legend(plot_legend)
    plt.savefig(f"plots/part_b/part_ii_f_{number_of_function}")
    plt.show()


def part_b_iii(function, array_of_lambda_functions, x, number_of_function):
    iterations = 200
    list_of_a = [0.01, 0.1, 1]
    list_of_b1 = [0.25, 0.9]
    list_of_b2 = [0.9, 0.999]
    list_of_iterations = list(range(iterations + 1))
    plot_legend = []
    colors = ['red', 'green', 'blue', 'orange', 'purple', 'cyan']
    index_of_color = 0
    for b2 in list_of_b2:
        for a in list_of_a:
            for b1 in list_of_b1:
                x_param_values_at_each_iteration, corresponding_values_of_function, steps_at_each_iteration = adam(
                    function, array_of_lambda_functions, x, [a, b1, b2], iterations)
                # function values vs iterations
                plt.figure(1)
                plt.plot(list_of_iterations, corresponding_values_of_function, color=colors[index_of_color])
                # x step size vs iterations
                step_size_x = [step[0] for step in steps_at_each_iteration]
                plt.figure(2)
                plt.plot(list_of_iterations, step_size_x, color=colors[index_of_color])
                # y step size vs iterations
                step_size_y = [step[1] for step in steps_at_each_iteration]
                plt.figure(3)
                plt.plot(list_of_iterations, step_size_y, color=colors[index_of_color])
                plot_legend.append(f'alpha_0={a}, beta_1={b1}')
                print(f'final value = {corresponding_values_of_function[-1]} when alpha = {a}, beta 1 = {b1}, beta 2 = {b2}')
                index_of_color = (index_of_color + 1) % len(colors)
        plt.figure(1)
        plt.ylabel(f"f_{number_of_function}(x,y)")
        plt.xlabel("Iterations")
        plt.title(f"f_{number_of_function}(x,y) gradient descent with Adam using b_2={b2}")
        plt.legend(plot_legend)
        plt.savefig(f"plots/part_b/part_iii_f_{number_of_function}_b_2={b2}.png")
        plt.figure(2)
        plt.ylabel("step size of x")
        plt.xlabel("Iterations")
        plt.title(f"f_{number_of_function} with step size of x using b_2={b2}")
        plt.savefig(f"plots/part_b/part_iii_f_{number_of_function}_step_x_b_2={b2}.png")
        plt.figure(3)
        plt.ylabel("step size of y")
        plt.xlabel("Iterations")
        plt.title(f"Step size of y for f_{number_of_function} using b_2={b2}")
        plt.savefig(f"plots/part_b/part_iii_f_{number_of_function}_step_y_b_2={b2}.png")
        plt.show()


if __name__ == "__main__":
    # Create function 1 and function 2 as lamda functions
    function_1 = lambda x, y: 9 * (x - 5) ** 4 + 10 * (y - 2) ** 2
    function_2 = lambda x, y: 10 * abs(y - 2) + max(0, x - 5)

    # Differentiate function 1 and function 2 in terms of x and y
    print(get_derivative_of_functions())

    # Creating lambda functions from output
    differentiate_function_1_in_terms_of_x = lambda x: 36 * (x - 5) ** 3
    differentiate_function_1_in_terms_of_y = lambda y: 20 * y - 40
    differentiate_function_2_in_terms_of_x = lambda x: np.heaviside(x - 5, 0)
    differentiate_function_2_in_terms_of_y = lambda y: 10 * np.sign(y - 2)

    part_b_i(function_1, [differentiate_function_1_in_terms_of_x, differentiate_function_1_in_terms_of_y], [3, 0], 1)
    part_b_i(function_2, [differentiate_function_2_in_terms_of_x, differentiate_function_2_in_terms_of_y], [3, 0], 2)

    part_b_ii(function_1, [differentiate_function_1_in_terms_of_x, differentiate_function_1_in_terms_of_y], [3, 0], 1)
    part_b_ii(function_2, [differentiate_function_2_in_terms_of_x, differentiate_function_2_in_terms_of_y], [3, 0], 2)

    part_b_iii(function_1, [differentiate_function_1_in_terms_of_x, differentiate_function_1_in_terms_of_y], [3, 0], 1)
    part_b_iii(function_2, [differentiate_function_2_in_terms_of_x, differentiate_function_2_in_terms_of_y], [3, 0], 2)


