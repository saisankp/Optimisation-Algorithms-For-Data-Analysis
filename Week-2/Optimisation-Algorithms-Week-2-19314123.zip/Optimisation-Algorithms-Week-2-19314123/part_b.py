import matplotlib.pyplot as plt


def gradient_descent(function_y, initial_x_value, number_of_iterations, step_size, derivative):
    y_array = [function_y(initial_x_value)]
    x_array = [initial_x_value]
    for _ in range(number_of_iterations):
        step = step_size * derivative(initial_x_value)
        initial_x_value = initial_x_value - step
        y_array.append(function_y(initial_x_value))
        x_array.append(initial_x_value)
    return x_array, y_array


def ii():
    x_array, y_array = gradient_descent(function_y=lambda x: x ** 4, initial_x_value=1, number_of_iterations=100,
                                        step_size=0.1, derivative=lambda x: 4 * (x ** 3))
    iterations = list(range(101))
    plt.plot(iterations, x_array)
    plt.plot(iterations, y_array)
    plt.ylabel('Value')
    plt.xlabel('Iterations')
    plt.legend(['x', 'y(x)'])
    plt.show()


def iii():
    iterations = list(range(101))
    for step_size in [0.001, 0.01, 0.1]:
        for x, color in zip([0.1, 0.5, 1], ['green', 'red', 'purple']):
            x_array, y_array = gradient_descent(function_y=lambda x: x ** 4, initial_x_value=x,
                                                number_of_iterations=100,
                                                step_size=step_size, derivative=lambda x: 4 * (x ** 3))
            plt.plot(iterations, x_array, color=color)
            plt.plot(iterations, y_array, color=color, linestyle='dashed')
        plt.legend(['x = 0.1', 'y(x = 0.1)', 'x = 0.5', 'y(x = 0.5)', 'x = 1', 'y(x = 1)'])
        plt.ylabel('Value')
        plt.xlabel(f'Iterations')
        plt.title(f'\u03B1={step_size}')
        plt.show()


if __name__ == '__main__':
    ii()
    iii()
