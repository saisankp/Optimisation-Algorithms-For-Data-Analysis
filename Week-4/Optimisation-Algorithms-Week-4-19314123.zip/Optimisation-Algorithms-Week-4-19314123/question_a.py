import math
import sympy as sp
from copy import deepcopy


def get_derivative_of_functions():
    x, y = sp.symbols('x y', real=True)
    first_function = (9 * ((x - 5) ** 4)) + (10 * ((y - 2) ** 2))
    derivative_first_function_in_terms_of_x = sp.diff(first_function, x)
    derivative_first_function_in_terms_of_y = sp.diff(first_function, y)
    second_function = sp.Max(x - 5, 0) + (10 * sp.Abs(y - 2))
    derivative_second_function_in_terms_of_x = sp.diff(second_function, x)
    derivative_second_function_in_terms_of_y = sp.diff(second_function, y)
    return (derivative_first_function_in_terms_of_x, derivative_first_function_in_terms_of_y,
            derivative_second_function_in_terms_of_x, derivative_second_function_in_terms_of_y)


def polyak(function, array_of_lambda_functions, x0, iterations):
    number_of_parameters = len(array_of_lambda_functions)
    x = deepcopy(x0)
    x_param_values_at_each_iteration = [deepcopy(x)]
    corresponding_values_of_function = [function(*x)]
    steps_at_each_iteration = []
    epsilon = pow(10, -8)
    for _ in range(iterations):
        # Calculate the partial derivatives (sum of the squares of the gradients)
        sum_of_squares_of_gradients = 0
        for iteration in range(number_of_parameters):
            sum_of_squares_of_gradients += array_of_lambda_functions[iteration](x[iteration]) ** 2
        # Calculate the step size
        step_size = function(*x) / (sum_of_squares_of_gradients + epsilon)
        # Recalculate values
        for iteration in range(number_of_parameters):
            x[iteration] -= (step_size * array_of_lambda_functions[iteration](x[iteration]))
        x_param_values_at_each_iteration.append(deepcopy(x))
        corresponding_values_of_function.append(function(*x))
        steps_at_each_iteration.append(step_size)
    return x_param_values_at_each_iteration, corresponding_values_of_function, steps_at_each_iteration


def rms_prop(function, array_of_lambda_functions, x0, params, iterations):
    number_of_parameters = len(array_of_lambda_functions)
    x = deepcopy(x0)
    x_param_values_at_each_iteration = [deepcopy(x)]
    corresponding_values_of_function = [function(*x)]
    a_0, b = params
    steps_at_each_iteration = [[a_0] * number_of_parameters]
    epsilon = pow(10, -8)
    sums = number_of_parameters * [0]
    alphas = number_of_parameters * [a_0]
    for _ in range(iterations):
        # Recalculate values
        for iteration in range(number_of_parameters):
            # Compute steps
            x[iteration] -= alphas[iteration] * array_of_lambda_functions[iteration](x[iteration])
            sums[iteration] = (b * sums[iteration]) + ((1 - b) * (array_of_lambda_functions[iteration](x[iteration]) ** 2))
            alphas[iteration] = a_0 / ((math.sqrt(sums[iteration])) + epsilon)
        x_param_values_at_each_iteration.append(deepcopy(x))
        corresponding_values_of_function.append(function(*x))
        steps_at_each_iteration.append(deepcopy(alphas))
    return x_param_values_at_each_iteration, corresponding_values_of_function, steps_at_each_iteration


def heavy_ball(function, array_of_lambda_functions, x0, params, iterations):
    number_of_parameters = len(array_of_lambda_functions)
    x = deepcopy(x0)
    x_param_values_at_each_iteration = [deepcopy(x)]
    corresponding_values_of_function = [function(*x)]
    a, b = params
    steps_at_each_iteration = [0]
    epsilon = pow(10, -8)
    historical_sum_of_square_gradients = 0
    for _ in range(iterations):
        # Calculate sum of the squares of the gradients (partial derivatives)
        sum_of_squares_of_gradients = 0
        for iteration in range(number_of_parameters):
            sum_of_squares_of_gradients += array_of_lambda_functions[iteration](x[iteration]) ** 2
        # Calculate the step size
        historical_sum_of_square_gradients = (b * historical_sum_of_square_gradients) + (a * function(*x) / (sum_of_squares_of_gradients + epsilon))
        # Recalculate values
        for iteration in range(number_of_parameters):
            x[iteration] -= historical_sum_of_square_gradients * array_of_lambda_functions[iteration](x[iteration])
        x_param_values_at_each_iteration.append(deepcopy(x))
        corresponding_values_of_function.append(function(*x))
        steps_at_each_iteration.append(historical_sum_of_square_gradients)
    return x_param_values_at_each_iteration, corresponding_values_of_function, steps_at_each_iteration


def adam(function, array_of_lambda_functions, x0, params, iterations):
    number_of_parameters = len(array_of_lambda_functions)
    x = deepcopy(x0)
    x_param_values_at_each_iteration = [deepcopy(x)]
    corresponding_values_of_function = [function(*x)]
    steps_at_each_iteration = [[0] * number_of_parameters]
    alpha, b1, b2 = params
    epsilon = pow(10, -8)
    ms = [0] * number_of_parameters
    vs = [0] * number_of_parameters
    step = [0] * number_of_parameters
    iteration_count = 0
    for _ in range(iterations):
        # Compute steps
        iteration_count += 1
        # Recalculate values
        for iteration in range(number_of_parameters):
            ms[iteration] = (b1 * ms[iteration]) + ((1 - b1) * array_of_lambda_functions[iteration](x[iteration]))
            vs[iteration] = (b2 * vs[iteration]) + ((1 - b2) * (array_of_lambda_functions[iteration](x[iteration]) ** 2))
            m_hat = ms[iteration] / (1 - (b1 ** iteration_count))
            v_hat = vs[iteration] / (1 - (b2 ** iteration_count))
            step[iteration] = alpha * (m_hat / ((v_hat ** 0.5) + epsilon))
            x[iteration] -= step[iteration]
        x_param_values_at_each_iteration.append(deepcopy(x))
        corresponding_values_of_function.append(function(*x))
        steps_at_each_iteration.append(deepcopy(step))
    return x_param_values_at_each_iteration, corresponding_values_of_function, steps_at_each_iteration


