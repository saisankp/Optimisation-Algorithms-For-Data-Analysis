import numpy as np
from matplotlib import pyplot as plt

colors = [
    'red', 'blue', 'pink', 'green', 'orange',
    'purple', 'yellow', 'cyan', 'grey', 'olive',
]


def generate_contour_plot(filepath, func, T, x_values, function_values, range_for_plot=None, three_dimensional=True, legend=None):
    Z = []
    if range_for_plot is not None:
        X = np.linspace(*range_for_plot[0], 100)
        Y = np.linspace(*range_for_plot[1], 100)
    else:
        X = np.linspace(-15, 10, 100)
        Y = np.linspace(-15, 10, 100)
    for x in X:
        z = []
        for y in Y:
            z.append(func([x, y], T))
        Z.append(z)
    X, Y = np.meshgrid(X, Y)
    Z = np.array(Z)
    if not three_dimensional:
        plt.contour(X, Y, Z, 60)
        plt.xlabel('x_0')
        plt.ylabel('x_1')
        for i in range(len(x_values)):
            x1 = [x[0] for x in x_values[i]]
            x0 = [x[1] for x in x_values[i]]
            plt.plot(x0, x1, markersize=3, marker='x', color='dimgrey', markeredgecolor=colors[i])
            plt.xlim([-15, 10])
            plt.ylim([-15, 10])
    else:
        ax = plt.axes(projection='3d')
        ax.contour3D(X, Y, Z, 60)
        ax.set_xlabel('x_0')
        ax.set_ylabel('x_1')
        ax.set_zlabel('f(x, T)')
        for i in range(len(x_values)):
            x1 = [x[0] for x in x_values[i]]
            x0 = [x[1] for x in x_values[i]]
            ax.plot(x0, x1, function_values[i], markersize=3, marker='x', color='dimgrey', markeredgecolor=colors[i])
    if legend is not None:
        plt.legend(legend)
    plt.savefig(filepath)
    plt.show()
