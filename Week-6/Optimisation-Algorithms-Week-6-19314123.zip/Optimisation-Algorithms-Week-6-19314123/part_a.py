import numpy as np
import matplotlib.pyplot as plt
import sympy as sp
from loss_function import generate_trainingdata, f


def part_a_ii():
    # Ranges -15 <= x_0 <= 10 and -15 <= x_1 <= 10
    X = np.linspace(-15, 10, 100)
    Y = np.linspace(-15, 10, 100)
    Z = []
    T = generate_trainingdata()
    for x_val in X:
        z = []
        for y_val in Y:
            z.append(f([x_val, y_val], T))
        Z.append(z)
    _, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5), subplot_kw=dict(projection='3d'), gridspec_kw={'wspace': 0.2})
    X, Y = np.meshgrid(X, Y)
    Z = np.array(Z)
    ax1.set_title('Wireframe plot of f(x, N) for N=T')
    ax1.plot_wireframe(X, Y, Z, rstride=5, cstride=5)
    ax1.set_zlabel('f(x, T)')
    ax1.set_ylabel('x_1')
    ax1.set_xlabel('x_0')
    ax2.set_title('Contour plot of f(x, N) for N=T')
    ax2.contour3D(X, Y, Z, 60, cmap='plasma')
    ax2.set_zlabel('f(x, T)')
    ax2.set_ylabel('x_1')
    ax2.set_xlabel('x_0')
    plt.savefig("plots/part_a/ii.png")
    plt.show()


def part_a_iii():
    x0, x1, w0, w1 = sp.symbols('x0 x1 w0 w1', real=True)
    function_to_differentiate = sp.Min(18*(((x0-w0-1)**2)+((x1-w1-1)**2)), (((x0-w0-1)+10)**2)+(((x1-w1-1)+5)**2))
    differentiate_with_respect_to_x0 = sp.diff(function_to_differentiate, x0)
    differentiate_with_respect_to_x1 = sp.diff(function_to_differentiate, x1)
    return f, differentiate_with_respect_to_x0, differentiate_with_respect_to_x1


if __name__ == '__main__':
    part_a_ii()
    function_to_differentiate, differentiate_with_respect_to_x0, differentiate_with_respect_to_x1 = part_a_iii()
    print(differentiate_with_respect_to_x0)
    print(differentiate_with_respect_to_x1)