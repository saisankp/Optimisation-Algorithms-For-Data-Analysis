from copy import deepcopy
import numpy as np
from matplotlib import pyplot as plt
from loss_function import generate_trainingdata, f
from plot_utility import generate_contour_plot, colors
from stochastic_gradient_descent import StochasticGradientDescent
from stochastic_gradient_descent import StochasticGradientDescent


def part_b_i(function, derivative_functions):
    alphas = [0.1, 0.01, 0.001, 0.0001]
    x_values = []
    function_values = []
    iterations = 100
    iterations_as_list = list(range(iterations + 1))
    T = generate_trainingdata()
    for iteration, alpha in enumerate(alphas):
        stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                StochasticGradientDescent.STEP_CONSTANT,
                                                                {'alpha': alpha}, len(T), T)
        # We are using a batch size of T, so this is not a mini-batch iteration in reality
        for _ in range(iterations):
            stochastic_gradient_descent.minibatch_iteration()
        plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'], color=colors[iteration],
                 label=f'alpha={alpha}')
        function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
        x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
    plt.ylabel('f(x, T)')
    plt.ylim([0, 150])
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_b/i-plot.png")
    plt.show()
    generate_contour_plot("plots/part_b/i-contour.png", function, T, x_values, function_values,
                          three_dimensional=False, legend=[f'alpha={a}' for a in alphas])


def part_b_ii(function, derivative_functions):
    alpha = 0.1
    x_values = []
    function_values = []
    attempts = 5
    iterations = 10
    iterations_as_list = list(range(iterations + 1))
    T = generate_trainingdata()
    for attempt in range(attempts):
        stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                StochasticGradientDescent.STEP_CONSTANT,
                                                                {'alpha': alpha}, 5, T)
        for _ in range(iterations):
            stochastic_gradient_descent.minibatch_iteration()
        plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'], color=colors[attempt],
                 label=f'Attempt {attempt+1}')
        function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
        x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
    plt.ylabel('f(x, T)')
    plt.ylim([0, 20])
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_b/ii-plot.png")
    plt.show()
    generate_contour_plot("plots/part_b/ii-contour.png", function, T, x_values, function_values,
                          three_dimensional=False, legend=[f'Attempt {attempt+1}' for attempt in range(attempts)])


def part_b_iii(function, derivative_functions):
    batch_sizes = [1, 3, 5, 10, 25]
    alpha = 0.1
    x_values = []
    function_values = []
    iterations = 25
    iterations_as_list = list(range(iterations + 1))
    T = generate_trainingdata()
    for batch_iteration, batch_size in enumerate(batch_sizes):
        stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                StochasticGradientDescent.STEP_CONSTANT,
                                                                {'alpha': alpha}, batch_size, T)
        for _ in range(iterations):
            stochastic_gradient_descent.minibatch_iteration()
        plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'],
                 color=colors[batch_iteration], label=f'batch_size={batch_size}')
        function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
        x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
    plt.ylabel('f(x, T)')
    plt.ylim([0, 3])
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_b/iii-plot.png")
    plt.show()
    generate_contour_plot("plots/part_b/iii-contour.png", function, T, x_values, function_values,
                          three_dimensional=False, legend=[f'batch_size={batch_size}' for batch_size in batch_sizes])


def part_b_iv(function, derivative_functions):
    alphas = [0.1, 0.01, 0.001, 0.0001]
    x_values = []
    function_values = []
    iterations = 25
    iterations_as_list = list(range(iterations + 1))
    T = generate_trainingdata()
    for alpha_iteration, alpha in enumerate(alphas):
        stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                StochasticGradientDescent.STEP_CONSTANT,
                                                                {'alpha': alpha}, 5, T)
        for _ in range(iterations):
            stochastic_gradient_descent.minibatch_iteration()
        plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'],
                 color=colors[alpha_iteration],  label=f'alpha={alpha}')
        function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
        x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
    plt.ylabel('f(x, T)')
    plt.ylim([0, 120])
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_b/iv-plot.png")
    plt.show()
    generate_contour_plot("plots/part_b/iv-contour.png", function, T, x_values, function_values,
                          three_dimensional=False, legend=[f'alpha={alpha}' for alpha in alphas])


if __name__ == '__main__':
    df0 = lambda x0, x1, w0, w1: \
        (-36 * w0 + 36 * x0 - 36) * np.heaviside(
            -18 * (-w0 + x0 - 1) ** 2 + (-w0 + x0 + 9) ** 2 - 18 * (-w1 + x1 - 1) ** 2 + (-w1 + x1 + 4) ** 2, 0) + \
        (-2 * w0 + 2 * x0 + 18) * np.heaviside(
            18 * (-w0 + x0 - 1) ** 2 - (-w0 + x0 + 9) ** 2 + 18 * (-w1 + x1 - 1) ** 2 - (-w1 + x1 + 4) ** 2, 0)
    df1 = lambda x0, x1, w0, w1: \
        (-36 * w1 + 36 * x1 - 36) * np.heaviside(
            -18 * (-w0 + x0 - 1) ** 2 + (-w0 + x0 + 9) ** 2 - 18 * (-w1 + x1 - 1) ** 2 + (-w1 + x1 + 4) ** 2, 0) + \
        (-2 * w1 + 2 * x1 + 8) * np.heaviside(
            18 * (-w0 + x0 - 1) ** 2 - (-w0 + x0 + 9) ** 2 + 18 * (-w1 + x1 - 1) ** 2 - (-w1 + x1 + 4) ** 2, 0)
    part_b_i(f, [df0, df1])
    part_b_ii(f, [df0, df1])
    part_b_iii(f, [df0, df1])
    part_b_iv(f, [df0, df1])