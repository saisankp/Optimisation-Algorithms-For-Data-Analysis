from copy import deepcopy
from random import uniform
from timeit import timeit

import numpy as np
from matplotlib import pyplot as plt

from part_a import global_random_search


def global_population_search(function_to_optimize, number_of_parameters, min_and_max_for_each_param, N, M, iterations,
                             measure_time=False):
    # Min and max value of each parameter (l for lower bound and u for upper bound)
    l = []
    u = []
    for tuple_of_min_and_max in min_and_max_for_each_param:
        l.append(tuple_of_min_and_max[0])
        u.append(tuple_of_min_and_max[1])
    best_function_value_at_each_iteration = []
    best_point_at_each_iteration = []
    best_function_value = float('inf')
    best_point = None
    list_of_function_values = [0] * N
    list_of_points = []
    for _ in range(N):
        point = []
        for i in range(number_of_parameters):
            point.append(uniform(l[i], u[i]))
        list_of_points.append(point)
    for n_index in range(N):
        current_point = list_of_points[n_index]
        current_function_value = function_to_optimize(*current_point)
        list_of_function_values[n_index] = current_function_value
        if current_function_value < best_function_value:
            best_function_value = current_function_value
            best_point = deepcopy(current_point)
        if not measure_time:
            best_function_value_at_each_iteration.append(best_function_value)
            best_point_at_each_iteration.append(deepcopy(best_point))
    sort_two_lists_based_on_first_list = lambda list_one, list_two: map(list, zip(*sorted(zip(list_one, list_two))))
    fraction_to_replace_bottom_results_by = (N - M) // M
    lower_multiplication_value_for_m = 0.8
    upper_multiplication_value_for_m = 1.2
    for _ in range(iterations):
        list_of_function_values, list_of_points = sort_two_lists_based_on_first_list(list_of_function_values,
                                                                                     list_of_points)
        for m_index in range(M):
            current_point = list_of_points[m_index]
            for fraction_index in range(fraction_to_replace_bottom_results_by):
                perturbed_index = M + (m_index * fraction_to_replace_bottom_results_by) + fraction_index
                perturbed_point = [x * uniform(lower_multiplication_value_for_m, upper_multiplication_value_for_m) for x
                                   in current_point]
                list_of_function_values[perturbed_index] = function_to_optimize(*perturbed_point)
                list_of_points[perturbed_index] = deepcopy(perturbed_point)
                if list_of_function_values[perturbed_index] < best_function_value:
                    best_function_value = list_of_function_values[perturbed_index]
                    best_point = deepcopy(list_of_points[perturbed_index])
                if not measure_time:
                    best_function_value_at_each_iteration.append(best_function_value)
                    best_point_at_each_iteration.append(deepcopy(best_point))

    return best_point_at_each_iteration, best_function_value_at_each_iteration


def gradient_descent(function, partial_derivative_functions, n, initial_x_value, alpha, iterations, measure_time=False):
    current_point = deepcopy(initial_x_value)
    current_function_value = function(*current_point)
    function_values = []
    parameter_values = []
    if not measure_time:
        function_values.append(current_function_value)
        parameter_values.append(deepcopy(current_point))
    for _ in range(iterations):
        for i in range(n):
            current_point[i] = current_point[i] - (alpha * partial_derivative_functions[i](current_point[i]))
        current_function_value = function(*current_point)
        if not measure_time:
            function_values.append(current_function_value)
            parameter_values.append(deepcopy(current_point))

    return parameter_values, function_values


def get_first_function_and_derivatives():
    function = lambda x, y: 9 * (x - 5) ** 4 + 10 * (y - 2) ** 2
    derive_function_with_respect_to_x = lambda x: 36 * (x - 5) ** 3
    derive_function_with_respect_to_y = lambda y: 20 * y - 40
    return function, (derive_function_with_respect_to_x, derive_function_with_respect_to_y)


def get_second_function_and_derivatives():
    function = lambda x, y: 10 * abs(y - 2) + max(0, x - 5)
    derive_function_with_respect_to_x = lambda x: np.heaviside(x - 5, 0)
    derive_function_with_respect_to_y = lambda y: 10 * np.sign(y - 2)
    return function, (derive_function_with_respect_to_x, derive_function_with_respect_to_y)


def part_ii(function_name, function_and_derivatives):
    min_and_max_for_each_parameter = [[3, 7], [0, 4]]
    initial_x_value = [7, 7]
    number_of_parameters = 2
    f, df = function_and_derivatives
    iterations = 200
    N = 20
    M = 5
    iterations_for_pruning = 10

    print(f'Comparing global random search to gradient descent using {function_name}')
    # Measure time for algorithms
    time_for_global_random_search = timeit(lambda: global_random_search(f, number_of_parameters,
                                                                        min_and_max_for_each_parameter, N=iterations,
                                                                        measure_time=True), number=100)
    time_for_gradient_descent = timeit(lambda: gradient_descent(f, df, number_of_parameters, initial_x_value,
                                                                iterations=iterations,
                                                                measure_time=True, alpha=0.01), number=100)
    time_for_global_population_search = timeit(
        lambda: global_population_search(f, number_of_parameters, min_and_max_for_each_parameter, N=N, M=M,
                                         iterations=iterations_for_pruning, measure_time=True), number=100)

    print(f'Time for global random search: {time_for_global_random_search}')
    print(f'Time for gradient descent: {time_for_gradient_descent}')
    print(f'Time for global population search: {time_for_global_population_search}')
    # Run the algorithms
    global_random_search_best_point, global_random_search_best_function_value = global_random_search(f,
                                                                                                     number_of_parameters,
                                                                                                     min_and_max_for_each_parameter,
                                                                                                     N=iterations)
    gradient_descent_best_point, gradient_descent_best_function_value = gradient_descent(f, df, number_of_parameters,
                                                                                         initial_x_value,
                                                                                         iterations=iterations,
                                                                                         alpha=0.01)
    global_population_search_best_point, global_population_search_best_function_value = global_population_search(f,
                                                                                                                 number_of_parameters,
                                                                                                                 min_and_max_for_each_parameter,
                                                                                                                 N=N,
                                                                                                                 M=M,
                                                                                                                 iterations=iterations_for_pruning)
    print(f'Minimum for global random search = {global_random_search_best_function_value[-1]}')
    print(f'Minimum for gradient descent = {gradient_descent_best_function_value[-1]}')
    print(f'Minimum for global population search = {global_population_search_best_function_value[-1]}')

    # Plot measurements
    global_random_search_time_per_iteration = time_for_global_random_search / len(
        global_random_search_best_function_value)
    gradient_descent_time_per_iteration = time_for_gradient_descent / len(gradient_descent_best_function_value)
    global_population_search_time_per_iteration = time_for_global_population_search / len(
        global_population_search_best_function_value)
    global_random_search_function_evaluations = list(range(len(global_random_search_best_function_value)))
    gradient_descent_function_evaluations = list(range(len(gradient_descent_best_function_value)))
    global_population_search_function_evaluations = list(range(len(global_population_search_best_function_value)))
    global_random_search_execution_time = np.array(
        global_random_search_function_evaluations) * global_random_search_time_per_iteration
    gradient_descent_search_execution_time = np.array(
        gradient_descent_function_evaluations) * gradient_descent_time_per_iteration
    global_population_search_execution_time = np.array(
        global_population_search_function_evaluations) * global_population_search_time_per_iteration

    _, (plot_1, plot_2) = plt.subplots(1, 2, figsize=(10, 5))
    plot_1.plot(global_random_search_function_evaluations, global_random_search_best_function_value,
                label='Global Random Search', color='red')

    plot_1.plot(gradient_descent_function_evaluations, gradient_descent_best_function_value,
                label=f'Gradient descent \n(alpha=0.01)', color='blue')

    plot_1.plot(global_population_search_function_evaluations, global_population_search_best_function_value,
                label='Global Population Search', color='tab:green')

    plot_1.set_ylim(0, 6)
    plot_1.set_xlabel('Evaluations of the function')
    plot_1.set_ylabel(function_name)
    plot_1.legend()
    plot_2.plot(global_random_search_execution_time, global_random_search_best_function_value,
                label='Global Random Search', color='red')
    plot_2.plot(gradient_descent_search_execution_time, gradient_descent_best_function_value,
                label=f'Gradient descent \n(alpha=0.01)', color='blue')
    plot_2.plot(global_population_search_execution_time, global_population_search_best_function_value,
                label='Global Population Search', color='tab:green')
    plot_2.set_ylim(0, 6)
    plot_2.set_xlabel('Time (in seconds)')
    plot_2.set_ylabel(function_name)
    plot_2.legend()
    plt.savefig(f"plots/b_{function_name[0:2]}")
    plt.show()
    X = np.linspace(-3, 8, 100)
    Y = np.linspace(-3, 8, 100)
    if function_name == "f2(x,y)":
        X = np.linspace(0, 8, 100)
        Y = np.linspace(0, 8, 100)
    Z = []
    for x in X:
        z = []
        for y in Y: z.append(f(x, y))
        Z.append(z)
    X, Y = np.meshgrid(X, Y)
    Z = np.array(Z)
    plt.ylabel('x_1')
    plt.xlabel('x_0')
    plt.contour(X, Y, Z, 100)
    plt.plot([x[1] for x in global_random_search_best_point], [x[0] for x in global_random_search_best_point],
             color='dimgrey', label='Global Random Search', marker='x', markeredgecolor='red', markersize=3)
    plt.plot([x[1] for x in gradient_descent_best_point], [x[0] for x in gradient_descent_best_point],
             color='dimgrey', label='Gradient descent', marker='x', markeredgecolor='blue', markersize=3)
    plt.plot([x[1] for x in global_population_search_best_point], [x[0] for x in global_population_search_best_point],
             color='dimgrey', label='Global Population Search', marker='x', markeredgecolor='green', markersize=3)
    plt.legend()
    plt.xlim([-3, 8])
    plt.ylim([0, 8])
    if function_name == "f2(x,y)":
        plt.xlim([0, 7])
        plt.ylim([1, 8])
    plt.savefig(f"plots/b_contour_{function_name[0:2]}")
    plt.show()


if __name__ == '__main__':
    part_ii("f1(x,y)", get_first_function_and_derivatives())
    part_ii("f2(x,y)", get_second_function_and_derivatives())
