import numpy as np
from matplotlib import pyplot as plt
from question_a import rms_prop, heavy_ball, adam


def part_c(iterations, function, function_derivative):
    list_of_iterations = list(range(iterations + 1))
    colors = ['red', 'green', 'blue', 'orange', 'purple', 'cyan']
    index_of_color = 0
    for x0 in [-1, 1, 100]:
        _, values, _ = rms_prop(function, [function_derivative], [x0], [0.01, 0.9], iterations)
        print(f'RMSProp (x0={x0}): {values[-1]}')
        plt.plot(list_of_iterations, values, color=colors[0])
        _, values, _ = heavy_ball(function, [function_derivative], [x0], [1, 0.25], iterations)
        print(f'Heavy Ball (x0={x0}): {values[-1]}')
        plt.plot(list_of_iterations, values, color=colors[1])
        _, values, _ = adam(function, [function_derivative], [x0], [0.01, 0.9, 0.999], iterations)
        print(f'Adam (x0={x0}): {values[-1]}')
        plt.plot(list_of_iterations, values, color=colors[2])
        index_of_color += 1
        plt.legend(['RMSProp', 'Heavy Ball', 'Adam'])
        plt.ylabel('f(x)')
        plt.xlabel(f'Iterations (x_0={x0})')
        plt.savefig(f"plots/part_c/iterations={iterations}_x_0={x0}.png")
        plt.show()


if __name__ == "__main__":
    function = lambda x: max(x, 0)
    function_derivative = lambda x: np.heaviside(x, 0)
    # Run for 100 iterations (+5 as buffer)
    part_c(105, function, function_derivative)
    # Run for 10,000 iterations (+500 as buffer)
    part_c(10500, function, function_derivative)
