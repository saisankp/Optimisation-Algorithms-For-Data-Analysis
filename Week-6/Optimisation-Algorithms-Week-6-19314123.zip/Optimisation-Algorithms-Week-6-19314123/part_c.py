from copy import deepcopy
import numpy as np
from matplotlib import pyplot as plt
from loss_function import generate_trainingdata, f
from plot_utility import colors, generate_contour_plot
from stochastic_gradient_descent import StochasticGradientDescent


def part_c_i(function, derivative_functions):
    index_of_color = 0
    x_values = []
    function_values = []
    iterations = 100
    iterations_as_list = list(range(iterations + 1))
    T = generate_trainingdata()
    # Stochastic gradient descent as a baseline for first iteration
    labels = ['Baseline']
    stochastic_gradient_descent_baseline = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                     StochasticGradientDescent.STEP_CONSTANT,
                                                                     {'alpha': 0.1}, 5, T)
    for _ in range(iterations):
        stochastic_gradient_descent_baseline.minibatch_iteration()
    plt.plot(iterations_as_list, stochastic_gradient_descent_baseline.logs['function_value'], label=labels[0],
             color=colors[index_of_color])
    function_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['function_value']))
    x_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['x_value']))
    index_of_color += 1
    # Stochastic gradient descent using polyak step size for remaining iterations
    batch_sizes = [1, 3, 5, 10, 25]
    for batch_size in batch_sizes:
        stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                StochasticGradientDescent.STEP_POLYAK,
                                                                {}, batch_size, T)
        for _ in range(iterations):
            stochastic_gradient_descent.minibatch_iteration()
        labels.append(f'batch_size={batch_size}')
        plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'], label=labels[-1],
                 color=colors[index_of_color])
        function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
        x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
        index_of_color += 1
    plt.ylabel('f(x, T)')
    plt.ylim([0, 60])
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_c/i-plot.png")
    plt.show()
    generate_contour_plot("plots/part_c/i-contour.png", function, T, x_values, function_values, three_dimensional=False,
                          legend=labels)


def part_c_ii(function, derivative_functions):
    index_of_color = 0
    x_values = []
    function_values = []
    iterations = 100
    iterations_as_list = list(range(iterations + 1))
    T = generate_trainingdata()
    # Stochastic gradient descent as a baseline for first iteration
    labels = ['Baseline']
    stochastic_gradient_descent_baseline = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                     StochasticGradientDescent.STEP_CONSTANT,
                                                                     {'alpha': 0.1}, 5, T)
    for _ in range(iterations):
        stochastic_gradient_descent_baseline.minibatch_iteration()
    plt.plot(iterations_as_list, stochastic_gradient_descent_baseline.logs['function_value'], label=labels[0],
             color=colors[index_of_color])
    function_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['function_value']))
    x_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['x_value']))
    index_of_color += 1

    # Stochastic gradient descent using RMSProp step size for remaining iterations to find best hyperparameters
    list_of_alpha_0 = [0.1, 0.01, 0.001]
    list_of_beta = [0.25, 0.9]
    for a0 in list_of_alpha_0:
        for b in list_of_beta:
            stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                    StochasticGradientDescent.STEP_RMSPROP,
                                                                    {'alpha0': a0, 'beta': b}, 5, T)
            for _ in range(iterations):
                stochastic_gradient_descent.minibatch_iteration()
            labels.append(f'alpha_0={a0}, beta={b}')
            plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'], label=labels[-1],
                     color=colors[index_of_color])
            function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
            x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
            index_of_color += 1
    plt.ylabel('f(x, T)')
    plt.ylim([0, 60])
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_c/ii-plot.png")
    plt.show()

    # Stochastic gradient descent using RMSProp step size using the best hyperparameters to explore various batch sizes
    index_of_color = 0
    x_values = []
    function_values = []
    labels = ['Baseline']
    plt.plot(iterations_as_list, stochastic_gradient_descent_baseline.logs['function_value'], label=labels[0],
             color=colors[index_of_color])
    index_of_color += 1
    x_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['x_value']))
    function_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['function_value']))
    batch_sizes = [1, 3, 5, 10, 25]
    for batch_size in batch_sizes:
        sgd = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                        StochasticGradientDescent.STEP_RMSPROP, {'alpha0': 0.1, 'beta': 0.9}, 5, T)
        for _ in range(iterations):
            sgd.minibatch_iteration()
        labels.append(f'batch_size={batch_size}')
        plt.plot(iterations_as_list, sgd.logs['function_value'], label=labels[-1], color=colors[index_of_color])
        function_values.append(deepcopy(sgd.logs['function_value']))
        x_values.append(deepcopy(sgd.logs['x_value']))
        index_of_color += 1
    plt.ylabel('f(x, T)')
    plt.ylim([0, 10])
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_c/ii-plot-2.png")
    plt.show()
    generate_contour_plot("plots/part_c/ii-contour.png", function, T, x_values, function_values,
                          three_dimensional=False, legend=labels)


def part_c_iii(function, derivative_functions):
    index_of_color = 0
    x_values = []
    function_values = []
    iterations = 100
    iterations_as_list = list(range(iterations + 1))
    T = generate_trainingdata()
    # Stochastic gradient descent as a baseline for first iteration
    labels = ['Baseline']
    stochastic_gradient_descent_baseline = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                     StochasticGradientDescent.STEP_CONSTANT,
                                                                     {'alpha': 0.1}, 5, T)
    for _ in range(iterations):
        stochastic_gradient_descent_baseline.minibatch_iteration()
    plt.plot(iterations_as_list, stochastic_gradient_descent_baseline.logs['function_value'], label=labels[0],
             color=colors[index_of_color])
    function_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['function_value']))
    x_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['x_value']))
    index_of_color += 1

    # Stochastic gradient descent using Heavyball step size to find best hyperparameters
    alphas = [0.01, 0.001]
    betas = [0.25, 0.5, 0.9]
    for alpha in alphas:
        for beta in betas:
            stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                    StochasticGradientDescent.STEP_HEAVYBALL,
                                                                    {'alpha': alpha, 'beta': beta}, 5, T)
            for _ in range(iterations):
                stochastic_gradient_descent.minibatch_iteration()
            labels.append(f'alpha={alpha}, beta={beta}')
            plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'], label=labels[-1],
                     color=colors[index_of_color])
            function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
            x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
            index_of_color += 1
    plt.ylim([0, 60])
    plt.ylabel('f(x, T)')
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_c/iii-plot.png")
    plt.show()

    # Stochastic gradient descent using Heavyball step size with the best hyperparameters to explore various batch sizes
    index_of_color = 0
    x_values = []
    function_values = []
    labels = ['Baseline']
    plt.plot(iterations_as_list, stochastic_gradient_descent_baseline.logs['function_value'], label=labels[0],
             color=colors[index_of_color])
    index_of_color += 1
    x_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['x_value']))
    function_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['function_value']))
    batch_sizes = [1, 3, 5, 10, 25]
    for batch_size in batch_sizes:
        stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                StochasticGradientDescent.STEP_HEAVYBALL,
                                                                {'alpha': 0.01, 'beta': 0.9}, 5, T)
        for _ in range(iterations):
            stochastic_gradient_descent.minibatch_iteration()
        labels.append(f'batch_size={batch_size}')
        plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'], label=labels[-1],
                 color=colors[index_of_color])
        function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
        x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
        index_of_color += 1
    plt.ylabel('f(x, T)')
    plt.ylim([0, 10])
    plt.xlabel('Iterations')
    plt.legend()
    plt.show()
    plt.savefig("plots/part_c/iii-plot-2.png")
    generate_contour_plot("plots/part_c/iii-contour.png", function, T, x_values, function_values,
                          three_dimensional=False, legend=labels)


def part_c_iv(function, derivative_functions):
    index_of_color = 0
    x_values = []
    function_values = []
    iterations = 100
    iterations_as_list = list(range(iterations + 1))
    T = generate_trainingdata()
    # Stochastic gradient descent as a baseline for first iteration
    labels = ['Baseline']
    stochastic_gradient_descent_baseline = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                     StochasticGradientDescent.STEP_CONSTANT,
                                                                     {'alpha': 0.1}, 5, T)
    for _ in range(iterations):
        stochastic_gradient_descent_baseline.minibatch_iteration()
    plt.plot(iterations_as_list, stochastic_gradient_descent_baseline.logs['function_value'], label=labels[0],
             color=colors[index_of_color])
    function_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['function_value']))
    x_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['x_value']))
    index_of_color += 1

    # Stochastic gradient descent using Adam step size to find best hyperparameters
    list_of_alphas = [10, 1, 0.1]
    list_of_beta_1 = [0.25, 0.9]
    list_of_beta_2 = [0.999]
    for a in list_of_alphas:
        for b1 in list_of_beta_1:
            for b2 in list_of_beta_2:
                stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                        StochasticGradientDescent.STEP_ADAM,
                                                                        {'alpha': a, 'beta1': b1, 'beta2': b2}, 5, T)
                for _ in range(iterations):
                    stochastic_gradient_descent.minibatch_iteration()
                labels.append(
                    f'alpha={a}, beta_1={b1}, beta_2={b2}'
                )
                plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'], label=labels[-1],
                         color=colors[index_of_color])
                function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
                x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
                index_of_color += 1
    plt.ylabel('f(x, T)')
    plt.ylim([0, 60])
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_c/iv-plot.png")
    plt.show()

    # Stochastic gradient descent using Adam step size with the best hyperparameters to explore various batch sizes
    batch_sizes = [1, 3, 5, 10, 25]
    index_of_color = 0
    x_values = []
    function_values = []
    labels = ['Baseline']
    plt.plot(iterations_as_list, stochastic_gradient_descent_baseline.logs['function_value'], label=labels[0],
             color=colors[index_of_color])
    function_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['function_value']))
    x_values.append(deepcopy(stochastic_gradient_descent_baseline.logs['x_value']))
    index_of_color += 1
    for batch_size in batch_sizes:
        stochastic_gradient_descent = StochasticGradientDescent(function, derivative_functions, [3, 3],
                                                                StochasticGradientDescent.STEP_ADAM,
                                                                {'alpha': 10, 'beta1': 0.9, 'beta2': 0.999}, 5, T)
        for _ in range(iterations):
            stochastic_gradient_descent.minibatch_iteration()
        labels.append(f'batch_size={batch_size}')
        plt.plot(iterations_as_list, stochastic_gradient_descent.logs['function_value'], label=labels[-1],
                 color=colors[index_of_color])
        function_values.append(deepcopy(stochastic_gradient_descent.logs['function_value']))
        x_values.append(deepcopy(stochastic_gradient_descent.logs['x_value']))
        index_of_color += 1
    plt.ylim([0, 10])
    plt.ylabel('f(x, T)')
    plt.xlabel('Iterations')
    plt.legend()
    plt.savefig("plots/part_c/iv-plot-2.png")
    plt.show()
    generate_contour_plot("plots/part_c/iv-contour.png", function, T, x_values, function_values,
                          three_dimensional=False, legend=labels)


if __name__ == '__main__':
    df0 = lambda x0, x1, w0, w1: \
        (-36 * w0 + 36 * x0 - 36) * np.heaviside(
            -18 * (-w0 + x0 - 1) ** 2 + (-w0 + x0 + 9) ** 2 - 18 * (-w1 + x1 - 1) ** 2 + (-w1 + x1 + 4) ** 2, 0) + \
        (-2 * w0 + 2 * x0 + 18) * np.heaviside(
            18 * (-w0 + x0 - 1) ** 2 - (-w0 + x0 + 9) ** 2 + 18 * (-w1 + x1 - 1) ** 2 - (-w1 + x1 + 4) ** 2, 0)
    df1 = lambda x0, x1, w0, w1: \
        (-36 * w1 + 36 * x1 - 36) * np.heaviside(
            -18 * (-w0 + x0 - 1) ** 2 + (-w0 + x0 + 9) ** 2 - 18 * (-w1 + x1 - 1) ** 2 + (-w1 + x1 + 4) ** 2, 0) + \
        (-2 * w1 + 2 * x1 + 8) * np.heaviside(
            18 * (-w0 + x0 - 1) ** 2 - (-w0 + x0 + 9) ** 2 + 18 * (-w1 + x1 - 1) ** 2 - (-w1 + x1 + 4) ** 2, 0)
    part_c_i(f, [df0, df1])
    part_c_ii(f,[df0, df1])
    part_c_iii(f, [df0, df1])
    part_c_iv(f, [df0, df1])
