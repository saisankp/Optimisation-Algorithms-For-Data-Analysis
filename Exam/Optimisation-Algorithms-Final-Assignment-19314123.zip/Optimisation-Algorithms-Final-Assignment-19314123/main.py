from matplotlib import pyplot as plt
from sgd_run import sgd_run
import tensorflow as tf


def experimenting_mini_batch_size_with_overfitting():
    # This command makes tensorflow use the CPU to avoid OOM (out of memory) errors using the GPU
    tf.config.set_visible_devices([], 'GPU')
    # Used [16, 1024, 4096, 16394, 32768, 56000] initially, but it was too big and had the same conclusions as below
    mini_batch_sizes = [16, 32, 64, 128, 256, 512, 1024]

    # Lists to store the results
    test_losses = []
    test_accuracies = []
    training_losses = []
    training_accuracies = []
    validation_losses = []
    validation_accuracies = []
    average_variances_in_gradient = []

    for mini_batch_size in mini_batch_sizes:
        print(f"Using mini-batch size: {mini_batch_size}")
        test_losses_from_runs = []
        test_accuracies_from_runs = []
        training_losses_from_runs = []
        training_accuracies_from_runs = []
        validation_losses_from_runs = []
        validation_accuracies_from_runs = []
        average_variances_in_gradient_from_runs = []
        run_attempts = [1, 2, 3]
        for _ in run_attempts:
            (test_loss, test_accuracy, training_loss, training_accuracy, validation_loss, validation_accuracy,
             average_variance_in_gradient) = (
                sgd_run(mini_batch_size=mini_batch_size, epochs=20, step_size=0.0001))
            test_losses_from_runs.append(test_loss)
            test_accuracies_from_runs.append(test_accuracy)
            training_losses_from_runs.append(training_loss)
            training_accuracies_from_runs.append(training_accuracy)
            validation_losses_from_runs.append(validation_loss)
            validation_accuracies_from_runs.append(validation_accuracy)
            average_variances_in_gradient_from_runs.append(average_variance_in_gradient)
        # Append results to lists
        test_losses.append(sum(test_losses_from_runs) / len(test_losses_from_runs))
        test_accuracies.append(sum(test_accuracies_from_runs) / len(test_accuracies_from_runs))
        training_losses.append(sum(training_losses_from_runs) / len(training_losses_from_runs))
        training_accuracies.append(sum(training_accuracies_from_runs) / len(training_accuracies_from_runs))
        validation_losses.append(sum(validation_losses_from_runs) / len(validation_losses_from_runs))
        validation_accuracies.append(sum(validation_accuracies_from_runs) / len(validation_accuracies_from_runs))
        average_variances_in_gradient.append(
            sum(average_variances_in_gradient_from_runs) / len(average_variances_in_gradient_from_runs))

    plt.figure(figsize=(10, 6))
    plt.plot(mini_batch_sizes, test_losses, label='Average test loss')
    plt.plot(mini_batch_sizes, training_losses, label='Average training loss')
    plt.plot(mini_batch_sizes, validation_losses, label='Average validation loss')
    plt.xlabel('Mini-batch size')
    plt.ylabel('Average loss')
    plt.title('Average loss vs Mini-batch size (20 epochs)')
    plt.legend()
    plt.savefig("plots/loss-for-mini-batch-size.png")
    plt.show()

    plt.figure(figsize=(10, 6))
    plt.plot(mini_batch_sizes, test_accuracies, label='Average test accuracy')
    plt.plot(mini_batch_sizes, training_accuracies, label='Average training accuracy')
    plt.plot(mini_batch_sizes, validation_accuracies, label='Average validation accuracy')
    plt.xlabel('Mini-batch size')
    plt.ylabel('Average accuracy')
    plt.title('Average accuracy vs Mini-batch size (20 epochs)')
    plt.legend()
    plt.savefig("plots/accuracy-for-mini-batch-size.png")
    plt.show()

    plt.figure(figsize=(10, 6))
    plt.plot(mini_batch_sizes, average_variances_in_gradient, label='Average variance in gradient across batches')
    plt.xlabel('Mini-batch size')
    plt.ylabel('Average variance in gradient across batches')
    plt.title('Average variance in gradient across batches vs Mini-batch size (20 epochs)')
    plt.legend()
    plt.savefig("plots/noise-for-mini-batch-size.png")
    plt.show()


def experimenting_gaussian_noise_with_overfitting():
    # This command makes tensorflow use the CPU to avoid OOM (out of memory) errors using the GPU
    tf.config.set_visible_devices([], 'GPU')
    gaussian_noises = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # Lists to store the results
    test_losses = []
    test_accuracies = []
    training_losses = []
    training_accuracies = []
    validation_losses = []
    validation_accuracies = []
    average_variances_in_gradient = []

    for gaussian_noise in gaussian_noises:
        print(f"Using gaussian noise: {gaussian_noise}")
        test_losses_from_runs = []
        test_accuracies_from_runs = []
        training_losses_from_runs = []
        training_accuracies_from_runs = []
        validation_losses_from_runs = []
        validation_accuracies_from_runs = []
        average_variances_in_gradient_from_runs = []
        run_attempts = [1, 2, 3]
        for _ in run_attempts:
            (test_loss, test_accuracy, training_loss, training_accuracy, validation_loss, validation_accuracy,
             average_variance_in_gradient) = (
                sgd_run(mini_batch_size=16, epochs=20, step_size=0.0001,
                        standard_deviation_for_gaussian_noise=gaussian_noise))
            test_losses_from_runs.append(test_loss)
            test_accuracies_from_runs.append(test_accuracy)
            training_losses_from_runs.append(training_loss)
            training_accuracies_from_runs.append(training_accuracy)
            validation_losses_from_runs.append(validation_loss)
            validation_accuracies_from_runs.append(validation_accuracy)
            average_variances_in_gradient_from_runs.append(average_variance_in_gradient)
        # Append results to lists
        test_losses.append(sum(test_losses_from_runs) / len(test_losses_from_runs))
        test_accuracies.append(sum(test_accuracies_from_runs) / len(test_accuracies_from_runs))
        training_losses.append(sum(training_losses_from_runs) / len(training_losses_from_runs))
        training_accuracies.append(sum(training_accuracies_from_runs) / len(training_accuracies_from_runs))
        validation_losses.append(sum(validation_losses_from_runs) / len(validation_losses_from_runs))
        validation_accuracies.append(sum(validation_accuracies_from_runs) / len(validation_accuracies_from_runs))
        average_variances_in_gradient.append(
            sum(average_variances_in_gradient_from_runs) / len(average_variances_in_gradient_from_runs))

    plt.figure(figsize=(10, 6))
    plt.plot(gaussian_noises, test_losses, label='Average test loss')
    plt.plot(gaussian_noises, training_losses, label='Average training loss')
    plt.plot(gaussian_noises, validation_losses, label='Average validation loss')
    plt.xlabel('Standard deviation of gaussian "noise"')
    plt.ylabel('Average loss')
    plt.title('Average loss vs Standard deviation of gaussian "noise" (20 epochs)')
    plt.legend()
    plt.savefig("plots/loss-for-noise.png")
    plt.show()

    plt.figure(figsize=(10, 6))
    plt.plot(gaussian_noises, test_accuracies, label='Average test accuracy')
    plt.plot(gaussian_noises, training_accuracies, label='Average training accuracy')
    plt.plot(gaussian_noises, validation_accuracies, label='Average validation accuracy')
    plt.xlabel('Standard deviation of gaussian "noise"')
    plt.ylabel('Average accuracy')
    plt.title('Average accuracy vs Standard deviation of gaussian "noise" (20 epochs)')
    plt.legend()
    plt.savefig("plots/accuracy-for-noise.png")
    plt.show()


def experimenting_step_size_schedule_with_overfitting():
    # This command makes tensorflow use the CPU to avoid OOM (out of memory) errors using the GPU
    tf.config.set_visible_devices([], 'GPU')
    step_sizes = [0.0001, 0.001, 0.01, 0.1]
    # Lists to store the results
    test_losses = []
    test_accuracies = []
    training_losses = []
    training_accuracies = []
    validation_losses = []
    validation_accuracies = []
    average_variances_in_gradient = []

    for step_size in step_sizes:
        print(f"Using step size: {step_size}")
        test_losses_from_runs = []
        test_accuracies_from_runs = []
        training_losses_from_runs = []
        training_accuracies_from_runs = []
        validation_losses_from_runs = []
        validation_accuracies_from_runs = []
        average_variances_in_gradient_from_runs = []
        run_attempts = [1, 2, 3]
        for _ in run_attempts:
            (test_loss, test_accuracy, training_loss, training_accuracy, validation_loss, validation_accuracy,
             average_variance_in_gradient) = (
                sgd_run(mini_batch_size=16, epochs=20, step_size=step_size))
            test_losses_from_runs.append(test_loss)
            test_accuracies_from_runs.append(test_accuracy)
            training_losses_from_runs.append(training_loss)
            training_accuracies_from_runs.append(training_accuracy)
            validation_losses_from_runs.append(validation_loss)
            validation_accuracies_from_runs.append(validation_accuracy)
            average_variances_in_gradient_from_runs.append(average_variance_in_gradient)
        # Append results to lists
        test_losses.append(sum(test_losses_from_runs) / len(test_losses_from_runs))
        test_accuracies.append(sum(test_accuracies_from_runs) / len(test_accuracies_from_runs))
        training_losses.append(sum(training_losses_from_runs) / len(training_losses_from_runs))
        training_accuracies.append(sum(training_accuracies_from_runs) / len(training_accuracies_from_runs))
        validation_losses.append(sum(validation_losses_from_runs) / len(validation_losses_from_runs))
        validation_accuracies.append(sum(validation_accuracies_from_runs) / len(validation_accuracies_from_runs))
        average_variances_in_gradient.append(
            sum(average_variances_in_gradient_from_runs) / len(average_variances_in_gradient_from_runs))

    plt.figure(figsize=(10, 6))
    plt.plot(step_sizes, test_losses, label='Average test loss')
    plt.plot(step_sizes, training_losses, label='Average training loss')
    plt.plot(step_sizes, validation_losses, label='Average validation loss')
    plt.xlabel('Initial step size')
    plt.ylabel('Average loss')
    plt.title('Average loss vs Step size with scheduler (20 epochs)')
    plt.legend()
    plt.savefig("plots/loss-for-step-size.png")
    plt.show()

    plt.figure(figsize=(10, 6))
    plt.plot(step_sizes, test_accuracies, label='Average test accuracy')
    plt.plot(step_sizes, training_accuracies, label='Average training accuracy')
    plt.plot(step_sizes, validation_accuracies, label='Average validation accuracy')
    plt.xlabel('Initial step size')
    plt.ylabel('Average accuracy')
    plt.title('Average accuracy vs Step size with scheduler (20 epochs)')
    plt.legend()
    plt.savefig("plots/accuracy-for-step-size.png")
    plt.show()


def experimenting_mini_batch_size_schedule_with_overfitting():
    # This command makes tensorflow use the CPU to avoid OOM (out of memory) errors using the GPU
    tf.config.set_visible_devices([], 'GPU')
    mini_batch_sizes = [16, 32, 64, 128, 256, 512, 1024]
    # Lists to store the results
    test_losses = []
    test_accuracies = []
    training_losses = []
    training_accuracies = []
    validation_losses = []
    validation_accuracies = []
    average_variances_in_gradient = []

    for mini_batch_size in mini_batch_sizes:
        print(f"Using mini_batch_size: {mini_batch_size}")
        test_losses_from_runs = []
        test_accuracies_from_runs = []
        training_losses_from_runs = []
        training_accuracies_from_runs = []
        validation_losses_from_runs = []
        validation_accuracies_from_runs = []
        average_variances_in_gradient_from_runs = []
        run_attempts = [1, 2, 3]
        for _ in run_attempts:
            (test_loss, test_accuracy, training_loss, training_accuracy, validation_loss, validation_accuracy,
             average_variance_in_gradient) = (
                sgd_run(mini_batch_size=mini_batch_size, epochs=20, step_size=0.01, mini_batch_scheduler=True))
            test_losses_from_runs.append(test_loss)
            test_accuracies_from_runs.append(test_accuracy)
            training_losses_from_runs.append(training_loss)
            training_accuracies_from_runs.append(training_accuracy)
            validation_losses_from_runs.append(validation_loss)
            validation_accuracies_from_runs.append(validation_accuracy)
            average_variances_in_gradient_from_runs.append(average_variance_in_gradient)
        # Append results to lists
        test_losses.append(sum(test_losses_from_runs) / len(test_losses_from_runs))
        test_accuracies.append(sum(test_accuracies_from_runs) / len(test_accuracies_from_runs))
        training_losses.append(sum(training_losses_from_runs) / len(training_losses_from_runs))
        training_accuracies.append(sum(training_accuracies_from_runs) / len(training_accuracies_from_runs))
        validation_losses.append(sum(validation_losses_from_runs) / len(validation_losses_from_runs))
        validation_accuracies.append(sum(validation_accuracies_from_runs) / len(validation_accuracies_from_runs))
        average_variances_in_gradient.append(
            sum(average_variances_in_gradient_from_runs) / len(average_variances_in_gradient_from_runs))

    plt.figure(figsize=(10, 6))
    plt.plot(mini_batch_sizes, test_losses, label='Average test loss')
    plt.plot(mini_batch_sizes, training_losses, label='Average training loss')
    plt.plot(mini_batch_sizes, validation_losses, label='Average validation loss')
    plt.xlabel('Initial mini-batch size')
    plt.ylabel('Average loss')
    plt.title('Average loss vs Mini-batch size with scheduler (20 epochs)')
    plt.legend()
    plt.savefig("plots/loss-for-scheduler-mini-batch.png")
    plt.show()

    plt.figure(figsize=(10, 6))
    plt.plot(mini_batch_sizes, test_accuracies, label='Average test accuracy')
    plt.plot(mini_batch_sizes, training_accuracies, label='Average training accuracy')
    plt.plot(mini_batch_sizes, validation_accuracies, label='Average validation accuracy')
    plt.xlabel('Initial mini-batch size')
    plt.ylabel('Average accuracy')
    plt.title('Average accuracy vs Mini-batch size with scheduler (20 epochs)')
    plt.legend()
    plt.savefig("plots/accuracy-for-scheduler-mini-batch.png")
    plt.show()


def experimenting_step_size_and_mini_batch_size_schedule_with_overfitting():
    # This command makes tensorflow use the CPU to avoid OOM (out of memory) errors using the GPU
    tf.config.set_visible_devices([], 'GPU')
    run_attempts = [1, 2, 3]
    # Lists to store the results
    test_losses = []
    test_accuracies = []
    training_losses = []
    training_accuracies = []
    validation_losses = []
    validation_accuracies = []
    average_variances_in_gradient = []

    for attempt in run_attempts:
        print(f"Run number: {attempt}")
        test_losses_from_runs = []
        test_accuracies_from_runs = []
        training_losses_from_runs = []
        training_accuracies_from_runs = []
        validation_losses_from_runs = []
        validation_accuracies_from_runs = []
        average_variances_in_gradient_from_runs = []
        average_run_attempts = [1, 2, 3]
        for _ in average_run_attempts:
            (test_loss, test_accuracy, training_loss, training_accuracy, validation_loss, validation_accuracy,
             average_variance_in_gradient) = (
                sgd_run(mini_batch_size=32, epochs=20, step_size=0.01, step_size_scheduler=True,
                        mini_batch_scheduler=True))
            test_losses_from_runs.append(test_loss)
            test_accuracies_from_runs.append(test_accuracy)
            training_losses_from_runs.append(training_loss)
            training_accuracies_from_runs.append(training_accuracy)
            validation_losses_from_runs.append(validation_loss)
            validation_accuracies_from_runs.append(validation_accuracy)
            average_variances_in_gradient_from_runs.append(average_variance_in_gradient)
        # Append results to lists
        test_losses.append(sum(test_losses_from_runs) / len(test_losses_from_runs))
        test_accuracies.append(sum(test_accuracies_from_runs) / len(test_accuracies_from_runs))
        training_losses.append(sum(training_losses_from_runs) / len(training_losses_from_runs))
        training_accuracies.append(sum(training_accuracies_from_runs) / len(training_accuracies_from_runs))
        validation_losses.append(sum(validation_losses_from_runs) / len(validation_losses_from_runs))
        validation_accuracies.append(sum(validation_accuracies_from_runs) / len(validation_accuracies_from_runs))
        average_variances_in_gradient.append(
            sum(average_variances_in_gradient_from_runs) / len(average_variances_in_gradient_from_runs))

    plt.figure(figsize=(10, 6))
    plt.plot(run_attempts, test_losses, label='Average test loss')
    plt.plot(run_attempts, training_losses, label='Average training loss')
    plt.plot(run_attempts, validation_losses, label='Average validation loss')
    plt.xlabel('Mini-batch and step size scheduler run attempt')
    plt.ylabel('Average loss')
    plt.title('Average loss vs Mini-batch and step size scheduler (20 epochs)')
    plt.legend()
    plt.xticks(range(1, 4))
    plt.savefig("plots/loss-for-scheduler-mini-batch-and-step-size.png")
    plt.show()

    plt.figure(figsize=(10, 6))
    plt.plot(run_attempts, test_accuracies, label='Average test accuracy')
    plt.plot(run_attempts, training_accuracies, label='Average training accuracy')
    plt.plot(run_attempts, validation_accuracies, label='Average validation accuracy')
    plt.xlabel('Mini-batch and step size scheduler run attempt')
    plt.ylabel('Average accuracy')
    plt.title('Average accuracy vs Mini-batch and step size scheduler (20 epochs)')
    plt.legend()
    plt.xticks(range(1, 4))
    plt.savefig("plots/accuracy-for-scheduler-mini-batch-and-step-size.png")
    plt.show()


def experimenting_adam_with_overfitting():
    # This command makes tensorflow use the CPU to avoid OOM (out of memory) errors using the GPU
    tf.config.set_visible_devices([], 'GPU')
    run_attempts = [1, 2, 3]
    # Lists to store the results
    test_losses = []
    test_accuracies = []
    training_losses = []
    training_accuracies = []
    validation_losses = []
    validation_accuracies = []
    average_variances_in_gradient = []

    tf.config.run_functions_eagerly(True)

    for attempt in run_attempts:
        print(f"Run number: {attempt}")
        test_losses_from_runs = []
        test_accuracies_from_runs = []
        training_losses_from_runs = []
        training_accuracies_from_runs = []
        validation_losses_from_runs = []
        validation_accuracies_from_runs = []
        average_variances_in_gradient_from_runs = []
        average_run_attempts = [1, 2, 3]
        for _ in average_run_attempts:
            (test_loss, test_accuracy, training_loss, training_accuracy, validation_loss, validation_accuracy,
             average_variance_in_gradient) = (
                sgd_run(mini_batch_size=16, epochs=20, step_size=None, adam_optimizer=True))
            test_losses_from_runs.append(test_loss)
            test_accuracies_from_runs.append(test_accuracy)
            training_losses_from_runs.append(training_loss)
            training_accuracies_from_runs.append(training_accuracy)
            validation_losses_from_runs.append(validation_loss)
            validation_accuracies_from_runs.append(validation_accuracy)
            average_variances_in_gradient_from_runs.append(average_variance_in_gradient)
        # Append results to lists
        test_losses.append(sum(test_losses_from_runs) / len(test_losses_from_runs))
        test_accuracies.append(sum(test_accuracies_from_runs) / len(test_accuracies_from_runs))
        training_losses.append(sum(training_losses_from_runs) / len(training_losses_from_runs))
        training_accuracies.append(sum(training_accuracies_from_runs) / len(training_accuracies_from_runs))
        validation_losses.append(sum(validation_losses_from_runs) / len(validation_losses_from_runs))
        validation_accuracies.append(sum(validation_accuracies_from_runs) / len(validation_accuracies_from_runs))
        average_variances_in_gradient.append(
            sum(average_variances_in_gradient_from_runs) / len(average_variances_in_gradient_from_runs))

    plt.figure(figsize=(10, 6))
    plt.plot(run_attempts, test_losses, label='Average test loss')
    plt.plot(run_attempts, training_losses, label='Average training loss')
    plt.plot(run_attempts, validation_losses, label='Average validation loss')
    plt.xlabel('Adam step size update attempts')
    plt.ylabel('Average loss')
    plt.title('Average loss vs Adam step size update attempts with default parameters (20 epochs)')
    plt.legend()
    plt.xticks(range(1, 4))
    plt.savefig("plots/loss-for-adam.png")
    plt.show()

    plt.figure(figsize=(10, 6))
    plt.plot(run_attempts, test_accuracies, label='Average test accuracy')
    plt.plot(run_attempts, training_accuracies, label='Average training accuracy')
    plt.plot(run_attempts, validation_accuracies, label='Average validation accuracy')
    plt.xlabel('Adam step size update attempts')
    plt.ylabel('Average accuracy')
    plt.title('Average accuracy vs Adam step size update attempts with default parameters (20 epochs)')
    plt.legend()
    plt.xticks(range(1, 4))
    plt.savefig("plots/accuracy-for-adam.png")
    plt.show()


if __name__ == "__main__":
    experimenting_mini_batch_size_with_overfitting()
    experimenting_gaussian_noise_with_overfitting()
    experimenting_step_size_schedule_with_overfitting()
    experimenting_mini_batch_size_schedule_with_overfitting()
    experimenting_step_size_and_mini_batch_size_schedule_with_overfitting()
    experimenting_adam_with_overfitting()
