# Note: The initial custom training and evaluation step format this code is based on is provided by tensorflow at:
# https://www.tensorflow.org/guide/keras/writing_a_training_loop_from_scratch
import numpy as np
import tensorflow as tf


# Step size scheduler (decreases the step size after every epoch)
def step_size_scheduler(initial_learning_rate, epoch):
    return initial_learning_rate * np.exp(0.04 * epoch + 1)


# Custom training step (calculates the gradients, with the ability to add Gaussian "noise")
@tf.function
def train_step(x, y, model, loss_function, optimizer, training_accuracy_metric, standard_deviation_for_gaussian_noise,
               step_size_scheduler, epoch, initial_learning_rate):
    with tf.GradientTape() as tape:
        training_logits = model(x, training=True)
        loss_value = loss_function(y, training_logits)
        loss_value += sum(model.losses)
    gradients = tape.gradient(loss_value, model.trainable_weights)
    gradients_with_gaussian_noise = [
        gradient + tf.random.normal(gradient.shape, mean=0.0, stddev=standard_deviation_for_gaussian_noise) for gradient
        in gradients]
    if step_size_scheduler:
        optimizer.learning_rate = step_size_scheduler(initial_learning_rate, epoch)
    optimizer.apply_gradients(zip(gradients_with_gaussian_noise, model.trainable_weights))
    training_accuracy_metric.update_state(y, training_logits)
    return loss_value, gradients


# Define custom evaluation step
@tf.function
def eval_step(x, y, model, loss_function, validation_accuracy_metric):
    validation_logits = model(x, training=False)
    loss_value = loss_function(y, validation_logits)
    validation_accuracy_metric.update_state(y, validation_logits)
    return loss_value
