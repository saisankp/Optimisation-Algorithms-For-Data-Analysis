import math
from copy import deepcopy
import numpy as np


class StochasticGradientDescent:
    # Constant values for stochastic gradient descent
    epsilon = 1e-8
    STEP_CONSTANT = 0
    STEP_POLYAK = 1
    STEP_RMSPROP = 2
    STEP_HEAVYBALL = 3
    STEP_ADAM = 4

    def __init__(self, function_being_minimized, derivative_functions, x_starting_value, step_size_choice,
                 hyperparameters_dict, batch_size, training_data):
        # Parameters for stochastic gradient descent
        self.function_being_minimized = function_being_minimized
        self.derivative_functions = derivative_functions
        self.number_of_parameters = len(x_starting_value)
        self.x_starting_value = deepcopy(x_starting_value)
        self.hyperparameters_dict = hyperparameters_dict
        # Parameters for minibatch stochastic gradient descent
        self.batch_size = batch_size
        self.training_data = training_data
        # Data for plotting
        self.logs = {
            'x_value': [deepcopy(self.x_starting_value)],
            'function_value': [self.function_being_minimized(self.x_starting_value, self.training_data)],
            'step': []
        }
        # Step size function
        self.iteration_function = self.iteration_function(step_size_choice)
        self.vars = None
        self.initialize_variables_for_function(step_size_choice)

    def compute_approximate_derivative(self, i, sample):
        return sum(
            self.derivative_functions[i](*self.x_starting_value, *sample[batch_size])
            for batch_size in range(self.batch_size)) / self.batch_size

    def iteration_function(self, step_size_choice):
        return {
            self.STEP_POLYAK: self.polyak_step_size,
            self.STEP_RMSPROP: self.rmsprop_step_size,
            self.STEP_HEAVYBALL: self.heavy_ball_step_size,
            self.STEP_ADAM: self.adam_step_size,
            self.STEP_CONSTANT: self.constant_step_size,
        }.get(step_size_choice, None)

    def initialize_variables_for_function(self, algo):
        if algo == self.STEP_ADAM:
            self.logs['step'] = [[0] * self.number_of_parameters]
            self.vars = {
                'ms': [0] * self.number_of_parameters,
                'vs': [0] * self.number_of_parameters,
                'step': [0] * self.number_of_parameters,
                't': 0
            }
        elif algo == self.STEP_HEAVYBALL:
            self.logs['step'] = [0]
            self.vars = {
                'z': 0
            }
        elif algo == self.STEP_RMSPROP:
            self.logs['step'] = [[self.hyperparameters_dict['alpha0']] * self.number_of_parameters]
            self.vars = {
                'sums': [0] * self.number_of_parameters,
                'alphas': [self.hyperparameters_dict['alpha0']] * self.number_of_parameters
            }

    def minibatch_iteration(self):
        np.random.shuffle(self.training_data)
        for starting_index_of_minibatch in range(0, len(self.training_data), self.batch_size):
            if starting_index_of_minibatch + self.batch_size > len(self.training_data):
                continue
            training_data_sample = self.training_data[starting_index_of_minibatch:(starting_index_of_minibatch +
                                                                                   self.batch_size)]
            self.iteration_function(training_data_sample)
        self.logs['function_value'].append(self.function_being_minimized(self.x_starting_value, self.training_data))
        self.logs['x_value'].append(deepcopy(self.x_starting_value))

    def polyak_step_size(self, sample):
        sum_of_squares_of_gradients = 0
        for iteration in range(self.number_of_parameters):
            sum_of_squares_of_gradients += self.compute_approximate_derivative(iteration, sample) ** 2
        step_size = (self.function_being_minimized(self.x_starting_value, sample) /
                     (sum_of_squares_of_gradients + self.epsilon))
        for iteration in range(self.number_of_parameters):
            self.x_starting_value[iteration] -= step_size * self.compute_approximate_derivative(iteration, sample)
        self.logs['step'].append(step_size)

    def rmsprop_step_size(self, sample):
        a_0 = self.hyperparameters_dict['alpha0']
        b = self.hyperparameters_dict['beta']
        sums = self.vars['sums']
        alphas = self.vars['alphas']
        for iteration in range(self.number_of_parameters):
            self.x_starting_value[iteration] -= (alphas[iteration] *
                                                 self.compute_approximate_derivative(iteration, sample))
            sums[iteration] = (b * sums[iteration]) + ((1 - b) *
                                                       (self.compute_approximate_derivative(iteration, sample) ** 2))
            alphas[iteration] = a_0 / ((math.sqrt(sums[iteration])) + self.epsilon)
        self.logs['step'].append(deepcopy(alphas))

    def heavy_ball_step_size(self, sample):
        a = self.hyperparameters_dict['alpha']
        b = self.hyperparameters_dict['beta']
        historical_sum_of_square_gradients = self.vars['z']
        # Calculate sum of the squares of the gradients (partial derivatives)
        sum_of_squares_of_gradients = 0
        for iteration in range(self.number_of_parameters):
            sum_of_squares_of_gradients += self.compute_approximate_derivative(iteration, sample) ** 2
        # Calculate the step size
        historical_sum_of_square_gradients = (b * historical_sum_of_square_gradients) + (
                a * self.function_being_minimized(self.x_starting_value, sample) /
                (sum_of_squares_of_gradients + self.epsilon))

        for i in range(self.number_of_parameters):
            self.x_starting_value[i] -= (historical_sum_of_square_gradients *
                                         self.compute_approximate_derivative(i, sample))
        self.vars['z'] = historical_sum_of_square_gradients
        self.logs['step'].append(historical_sum_of_square_gradients)

    def adam_step_size(self, sample):
        a = self.hyperparameters_dict['alpha']
        b1 = self.hyperparameters_dict['beta1']
        b2 = self.hyperparameters_dict['beta2']
        ms = self.vars['ms']
        vs = self.vars['vs']
        step = self.vars['step']
        iteration_count = self.vars['t']
        iteration_count += 1
        for iteration in range(self.number_of_parameters):
            ms[iteration] = (b1 * ms[iteration]) + ((1 - b1) * self.compute_approximate_derivative(iteration, sample))
            vs[iteration] = (b2 * vs[iteration]) + ((1 - b2) *
                                                    (self.compute_approximate_derivative(iteration, sample) ** 2))
            m_hat = ms[iteration] / (1 - (b1 ** iteration_count))
            v_hat = vs[iteration] / (1 - (b2 ** iteration_count))
            step[iteration] = a * (m_hat / ((v_hat ** 0.5) + self.epsilon))
            self.x_starting_value[iteration] -= step[iteration]
        self.vars['t'] = iteration_count
        self.logs['step'].append(deepcopy(step))

    def constant_step_size(self, sample):
        a = self.hyperparameters_dict['alpha']
        self.logs['step'].append(a)
        for i in range(self.number_of_parameters):
            self.x_starting_value[i] -= a * self.compute_approximate_derivative(i, sample)
