import matplotlib.pyplot as plt
import sympy as sp


def gradient_descent(function_y, initial_x_value, number_of_iterations, step_size, derivative):
    y_array = [function_y(initial_x_value)]
    x_array = [initial_x_value]
    for _ in range(number_of_iterations):
        step = step_size * derivative(initial_x_value)
        initial_x_value = initial_x_value - step
        y_array.append(function_y(initial_x_value))
        x_array.append(initial_x_value)
    return x_array, y_array


def i():
    # Finding the derivative of γx^2 is 2γx
    x = sp.Symbol('x')
    print(sp.diff(sp.Symbol('gamma') * (x ** 2), x))

    # Subsequently, using γx^2 as function_y and 2γx as the derivative
    iterations = list(range(101))
    for gamma, color in zip([0.1, 1, 2], ['green', 'red', 'purple']):
        x_array, y_array = gradient_descent(function_y=lambda x: gamma * (x ** 2), initial_x_value=1,
                                            number_of_iterations=100,
                                            step_size=0.1, derivative=lambda x: 2 * gamma * x)
        plt.plot(iterations, x_array, color=color)
        plt.plot(iterations, y_array, color=color, linestyle='dashed')
    plt.legend(['x [γ = 0.1]', 'y(x) [γ = 0.1]', 'x [γ = 1]', 'y(x) [γ = 1]', 'x [γ = 2]', 'y(x) [γ = 2]'])
    plt.ylabel('Value')
    plt.xlabel('Iterations')
    plt.show()


def ii():
    # Finding the derivative of γ|x| is (gamma*x)/|x|
    x = sp.Symbol('x')
    print(sp.diff(sp.Symbol('gamma') * abs(x), x))

    # Subsequently, using γ|x| as function_y and (gamma*x)/|x| as the derivative
    iterations = list(range(101))
    for gamma, color in zip([0.1, 1, 2], ['green', 'red', 'purple']):
        x_array, y_array = gradient_descent(function_y=lambda x: gamma * abs(x), initial_x_value=1,
                                            number_of_iterations=100,
                                            step_size=0.1, derivative=lambda x: gamma * x / abs(x))
        plt.plot(iterations, x_array, color=color)
        plt.plot(iterations, y_array, color=color, linestyle='dashed')
    plt.legend(['x [γ = 0.1]', 'y(x) [γ = 0.1]', 'x [γ = 1]', 'y(x) [γ = 1]', 'x [γ = 2]', 'y(x) [γ = 2]'])
    plt.ylabel('Value')
    plt.xlabel('Iterations')
    plt.show()


if __name__ == '__main__':
    i()
    ii()
