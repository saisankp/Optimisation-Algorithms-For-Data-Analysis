from keras import models, layers


def get_model(optimizer, loss_function):
    model = models.Sequential([
        layers.Input(shape=(28, 28, 1,)),
        layers.Conv2D(32, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.Conv2D(64, (3, 3), activation='relu'),
        layers.MaxPooling2D((2, 2)),
        layers.Conv2D(64, (3, 3), activation='relu'),
        layers.Flatten(),
        layers.Dense(64, activation='relu'),
        # We avoid using "kernel_regularizer=regularizers.l1(0.0001)" below since we want overfitting in this case!
        layers.Dense(10)
    ])
    model.compile(optimizer=optimizer, loss=loss_function, metrics=['accuracy'])
    return model
