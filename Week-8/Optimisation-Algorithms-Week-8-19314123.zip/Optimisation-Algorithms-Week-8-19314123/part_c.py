import matplotlib.pyplot as plt
from copy import deepcopy
from random import uniform
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D
from keras.losses import CategoricalCrossentropy
from keras import datasets, utils, Sequential, regularizers
from keras.optimizers import Adam


def part_i():
    # 5 parameters
    min_and_max_for_each_param = [[1, 128], [0.001, 0.001], [0.9, 0.9], [0.999, 0.999], [20, 20]]
    global_population_search_x_list, global_population_search_f_list = global_population_search(model_loss, 5,
                                                                                                min_and_max_for_each_param,
                                                                                                N=12, M=4, iterations=4)
    global_random_search_x_list, global_random_search_f_list = global_random_search(model_loss, 5,
                                                                                    min_and_max_for_each_param, N=50)
    return (global_random_search_x_list, global_random_search_f_list, global_population_search_x_list,
            global_population_search_f_list)


def part_ii():
    # 5 parameters and [45, 45] is from part (i)
    min_and_max_for_each_param = [[45, 45], [0.1, 0.0001], [0.25, 0.99], [0.9, 0.9999], [20, 20]]
    global_population_search_x_list, global_population_search_f_list = global_population_search(model_loss, 5,
                                                                                                min_and_max_for_each_param,
                                                                                                N=12, M=4,
                                                                                                iterations=4)
    global_random_search_x_list, global_random_search_f_list = global_random_search(model_loss, 5,
                                                                                    min_and_max_for_each_param, N=50)
    return global_random_search_x_list, global_random_search_f_list, global_population_search_x_list, global_population_search_f_list


def part_iii():
    # 5 parameters and [45, 45] is from part (i), index 1 to 3 were ignored from part (ii), then index 4 (i.e. [5,
    # 30]) is used now
    min_and_max_for_each_param = [[45, 45], [0.001, 0.001], [0.9, 0.9], [0.999, 0.999], [5, 30]]
    global_population_search_x_list, global_population_search_f_list = global_population_search(model_loss, 5,
                                                                                                min_and_max_for_each_param,
                                                                                                N=12, M=4,
                                                                                                iterations=4)
    global_random_search_x_list, global_random_search_f_list = global_random_search(model_loss, 5,
                                                                                    min_and_max_for_each_param, N=50)
    return global_random_search_x_list, global_random_search_f_list, global_population_search_x_list, global_population_search_f_list


def plot(global_random_search_function_value, global_population_search_function_value, hyperparameter):
    global_random_search_function_evaluations, global_population_search_function_evaluations = len(global_random_search_function_value), len(global_population_search_function_value)
    global_random_search_evaluation_indices, global_population_search_evaluation_indices = list(range(global_random_search_function_evaluations)), list(range(global_population_search_function_evaluations))
    plt.plot(global_population_search_evaluation_indices, global_population_search_function_value, label='Global Population Search')
    plt.plot(global_random_search_evaluation_indices, global_random_search_function_value, label='Global Random Search')
    plt.ylabel('Model Loss')
    plt.xlabel('Evaluations of function')
    plt.legend()
    plt.savefig(f"plots/c_{hyperparameter}")
    plt.show()


# Credit for code in function: https://www.scss.tcd.ie/Doug.Leith/CSU44061/week8.py
def model_loss(mini_batch_size, a, b1, b2, number_of_epochs):
    epochs = int(number_of_epochs)
    mini_batch_size = int(mini_batch_size)
    num_classes = 10
    (x_train, y_train), (x_test, y_test) = datasets.cifar10.load_data()
    n = 5000
    y_train = y_train[1:n]
    x_train = x_train[1:n]
    y_test = utils.to_categorical(y_test, num_classes)
    x_test = x_test.astype("float32") / 255
    y_train = utils.to_categorical(y_train, num_classes)
    x_train = x_train.astype("float32") / 255
    model = Sequential()
    model.add(Conv2D(16, (3, 3), padding='same',
                     input_shape=x_train.shape[1:], activation='relu'))
    model.add(Conv2D(16, (3, 3), strides=(2, 2), padding='same', activation='relu'))
    model.add(Conv2D(32, (3, 3), padding='same', activation='relu'))
    model.add(Conv2D(32, (3, 3), strides=(2, 2), padding='same', activation='relu'))
    model.add(Dropout(0.5))
    model.add(Flatten())
    model.add(Dense(num_classes, activation='softmax',
                    kernel_regularizer=regularizers.l1(0.0001)))
    optimizer = Adam(learning_rate=a, beta_1=b1, beta_2=b2)
    model.compile(loss="categorical_crossentropy", optimizer=optimizer,
                  metrics=["accuracy"])
    model.fit(x_train, y_train, batch_size=mini_batch_size, epochs=epochs,
              validation_split=0.1, verbose=0)
    y_preds = model.predict(x_test)
    loss = CategoricalCrossentropy()
    return loss(y_test, y_preds).numpy()


def global_random_search(function_to_optimize, number_of_parameters, min_and_max_for_each_param, N):
    # Min and max value of each parameter (l for lower bound and u for upper bound)
    l = []
    u = []
    for tuple_of_min_and_max in min_and_max_for_each_param:
        l.append(tuple_of_min_and_max[0])
        u.append(tuple_of_min_and_max[1])
    best_function_value_at_each_iteration = []
    best_point_at_each_iteration = []
    best_function_value = float('inf')
    best_point = None
    function_evaluations = 0
    for _ in range(N):
        current_point = []
        for i in range(number_of_parameters):
            current_point.append(uniform(l[i], u[i]))
        current_function_value = function_to_optimize(*current_point)
        if current_function_value < best_function_value:
            best_function_value = current_function_value
            best_point = deepcopy(current_point)
        best_function_value_at_each_iteration.append(best_function_value)
        best_point_at_each_iteration.append(deepcopy(best_point))
        print(function_evaluations, best_point, best_function_value)
        function_evaluations = function_evaluations + 1
    return best_point_at_each_iteration, best_function_value_at_each_iteration


def global_population_search(function_to_optimize, number_of_parameters, min_and_max_for_each_param, N, M, iterations):
    # Min and max value of each parameter (l for lower bound and u for upper bound)
    l = []
    u = []
    for tuple_of_min_and_max in min_and_max_for_each_param:
        l.append(tuple_of_min_and_max[0])
        u.append(tuple_of_min_and_max[1])
    best_function_value_at_each_iteration = []
    best_point_at_each_iteration = []
    best_function_value = float('inf')
    best_point = None
    list_of_function_values = [0] * N
    list_of_points = []
    function_evaluations = 0
    for _ in range(N):
        point = []
        for i in range(number_of_parameters):
            point.append(uniform(l[i], u[i]))
        list_of_points.append(point)
    for n_index in range(N):
        current_point = list_of_points[n_index]
        current_function_value = function_to_optimize(*current_point)
        list_of_function_values[n_index] = current_function_value
        if current_function_value < best_function_value:
            best_function_value = current_function_value
            best_point = deepcopy(current_point)
        best_function_value_at_each_iteration.append(best_function_value)
        best_point_at_each_iteration.append(deepcopy(best_point))
        print(function_evaluations, best_point, best_function_value)
        function_evaluations = function_evaluations + 1

    sort_two_lists_based_on_first_list = lambda list_one, list_two: map(list, zip(*sorted(zip(list_one, list_two))))
    fraction_to_replace_bottom_results_by = (N - M) // M
    lower_multiplication_value_for_m = 0.8
    upper_multiplication_value_for_m = 1.2
    function_evaluations = 0
    for _ in range(iterations):
        list_of_function_values, list_of_points = sort_two_lists_based_on_first_list(list_of_function_values,
                                                                                     list_of_points)
        for m_index in range(M):
            current_point = list_of_points[m_index]
            for fraction_index in range(fraction_to_replace_bottom_results_by):
                perturbed_index = M + (m_index * fraction_to_replace_bottom_results_by) + fraction_index
                perturbed_point = [x * uniform(lower_multiplication_value_for_m, upper_multiplication_value_for_m) for x
                                   in current_point]
                list_of_function_values[perturbed_index] = function_to_optimize(*perturbed_point)
                list_of_points[perturbed_index] = deepcopy(perturbed_point)
                if list_of_function_values[perturbed_index] < best_function_value:
                    best_function_value = list_of_function_values[perturbed_index]
                    best_point = deepcopy(list_of_points[perturbed_index])
                best_function_value_at_each_iteration.append(best_function_value)
                best_point_at_each_iteration.append(deepcopy(best_point))
        print(function_evaluations, best_point_at_each_iteration, best_function_value_at_each_iteration)
        function_evaluations = function_evaluations + 1
    return best_point_at_each_iteration, best_function_value_at_each_iteration


if __name__ == '__main__':
    _, global_random_search_function_value_part_1, _, global_population_search_function_value_part_1 = part_i()
    _, global_random_search_function_value_part_2, _, global_population_search_function_value_part_2 = part_ii()
    _, global_random_search_function_value_part_3, _, global_population_search_function_value_part_3 = part_iii()
    plot(global_random_search_function_value_part_1, global_population_search_function_value_part_1, "batch_size")
    plot(global_random_search_function_value_part_2, global_population_search_function_value_part_2, "adam_parameters")
    plot(global_random_search_function_value_part_3, global_population_search_function_value_part_3, "epoch_number")
