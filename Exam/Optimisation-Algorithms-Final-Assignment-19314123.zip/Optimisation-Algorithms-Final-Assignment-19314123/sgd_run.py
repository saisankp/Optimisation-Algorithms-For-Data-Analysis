# Note: The initial custom training and evaluation step format this code is based on is provided by tensorflow at:
# https://www.tensorflow.org/guide/keras/writing_a_training_loop_from_scratch
from math import floor

import tensorflow as tf
from tensorflow.python.keras import metrics
from keras import datasets, optimizers, losses
import numpy as np
from sklearn.model_selection import train_test_split

from custom_training_and_evaluation_steps import train_step, eval_step
from model import get_model


# One SGD run
def sgd_run(mini_batch_size=16, epochs=20, step_size=0.001, standard_deviation_for_gaussian_noise=0,
            step_size_scheduler=False, mini_batch_scheduler=False, adam_optimizer=False):
    # The Fashion MNIST dataset has a good chance of overfitting (increased complexity and variability as in report)
    (x_train, y_train), (x_test, y_test) = datasets.fashion_mnist.load_data()
    combined_x_data = np.concatenate((x_train, x_test))
    combined_y_data = np.concatenate((y_train, y_test))
    # Convert pixel values between 0 and 1
    combined_x_data = combined_x_data.astype('float32') / 255.0
    # Add an extra dimension so the shape of the image suits the CNN
    combined_x_data = np.expand_dims(combined_x_data, -1)
    # 80% of Fashion MNIST will be used for training
    x_train, x_test_and_validation, y_train, y_test_and_validation = train_test_split(combined_x_data, combined_y_data,
                                                                                      test_size=0.2)

    train_dataset = tf.data.Dataset.from_tensor_slices((x_train, y_train))
    train_dataset = train_dataset.shuffle(buffer_size=1024)

    # 10% of Fashion MNIST will be used for testing, and 10% for validation (not shared like cross-validation)
    x_test, x_validation, y_test, y_validation = train_test_split(x_test_and_validation, y_test_and_validation,
                                                                  test_size=0.5)
    validation_dataset = tf.data.Dataset.from_tensor_slices((x_validation, y_validation))
    batch_size_schedule = lambda epoch: max(floor(mini_batch_size - (0.01 * (epoch + 1) * mini_batch_size)), 8)

    if not mini_batch_scheduler:
        train_dataset = train_dataset.batch(mini_batch_size)
        validation_dataset = validation_dataset.batch(mini_batch_size)

    # Evaluation during training with sparse categorical crossentropy (suits Fashion MNIST's categorical classification)
    metric_for_training_accuracy = metrics.SparseCategoricalAccuracy()
    metric_for_validation_accuracy = metrics.SparseCategoricalAccuracy()

    if adam_optimizer:
        # Adam with defaults
        optimizer = optimizers.Adam(learning_rate=0.001, beta_1=0.9, beta_2=0.999, epsilon=1e-07)
    else:
        # Optimizer will be stochastic gradient descent with the learning rate (i.e. step size) passed in
        optimizer = optimizers.SGD(learning_rate=step_size)

    # Loss function will be sparse categorical crossentropy (suits Fashion MNIST's categorical classification)
    loss_function = losses.SparseCategoricalCrossentropy(from_logits=True)
    cnn_model = get_model(optimizer, loss_function)
    variances_of_gradients = []
    training_accuracies = []
    training_losses = []
    validation_accuracies = []
    validation_losses = []

    # Train the CNN model with custom training/evaluation steps, instead of cnn_model.fit(), so it can be tweaked
    for epoch in range(epochs):
        print(f"Epoch number: {epoch}")
        batch_gradients = []

        if mini_batch_scheduler:
            # Update the batch size after evert epoch with the batch size scheduler
            batch_size_from_scheduler = batch_size_schedule(epoch)
            train_dataset = tf.data.Dataset.from_tensor_slices((x_train, y_train))
            train_dataset = train_dataset.shuffle(buffer_size=1024)
            train_dataset = train_dataset.batch(batch_size_from_scheduler)
            validation_dataset = tf.data.Dataset.from_tensor_slices((x_validation, y_validation))
            validation_dataset = validation_dataset.batch(batch_size_from_scheduler)

        # Iterating over the training dataset's batches
        for _, (training_batch_for_x, training_batch_for_y) in enumerate(train_dataset):
            training_loss, gradient = train_step(training_batch_for_x, training_batch_for_y, cnn_model, loss_function,
                                                 optimizer, metric_for_training_accuracy,
                                                 standard_deviation_for_gaussian_noise, step_size_scheduler, epoch,
                                                 step_size)
            training_losses.append(training_loss)
            batch_gradients.append(np.var([np.var(g) for g in gradient]))

        variances_of_gradients.append(np.mean(batch_gradients))
        training_accuracy = metric_for_training_accuracy.result()
        training_accuracies.append(training_accuracy)
        metric_for_training_accuracy.reset_states()

        # Validation loop at the end of each epoch
        for validation_batch_for_x, validation_batch_for_y in validation_dataset:
            validation_loss = eval_step(validation_batch_for_x, validation_batch_for_y, cnn_model, loss_function,
                                        metric_for_validation_accuracy)
            validation_losses.append(validation_loss)
        validation_accuracy = metric_for_validation_accuracy.result()
        validation_accuracies.append(validation_accuracy)
        metric_for_training_accuracy.reset_states()

    # Once model is compiled and trained, evaluate the model
    test_loss, test_accuracy = cnn_model.evaluate(x_test, y_test, verbose=2)
    training_loss = float((sum(training_losses) / len(training_losses)))
    training_accuracy = float((sum(training_accuracies) / len(training_accuracies)))
    validation_loss = float((sum(validation_losses) / len(validation_losses)))
    validation_accuracy = float((sum(validation_accuracies) / len(validation_accuracies)))
    average_variance_in_gradient = float((sum(variances_of_gradients) / len(variances_of_gradients)))

    return test_loss, test_accuracy, training_loss, training_accuracy, validation_loss, validation_accuracy, average_variance_in_gradient
