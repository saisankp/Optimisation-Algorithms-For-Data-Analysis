import sympy as sp
import sympy.plotting as plt


def i():
    # Initialize variable x
    x = sp.symbols('x')
    # Create function y(x)=x^4 using variable x
    y = x ** 4
    # Find the derivative of y(x) using the diff() function
    derivative = sp.diff(y, x)
    return derivative


def ii(perturbation, x, derivative):
    # Range of x values
    x_range = (x, -3, 3)
    # First, plot the actual derivative
    plot = plt.plot(derivative, x_range, label='Real dy/dx', xlabel=' ' * 135 + 'x', ylabel=' ' * 95 + 'y(x)',
                    show=False)
    # Second, calculate the estimated derivative using a finite difference with the specified perturbation
    estimated_derivative = ((x + perturbation) ** 4 - x ** 4) / perturbation
    # Plot the estimated derivative and append it on top of the first plot
    plot.extend(plt.plot(estimated_derivative, x_range, label=f'Estimated dy/dx \n with δ={perturbation}',
                         show=False))
    plot.legend = True
    plot.show()


def iii(perturbation_values, x, derivative):
    # Range of x values
    x_range = (x, -3, 3)
    # First, plot the actual derivative
    plot = plt.plot(derivative, x_range, label='Real dy/dx', xlabel=' ' * 135 + 'x', ylabel=' ' * 95 + 'y(x)',
                    show=False)
    for perturbation in perturbation_values:
        # Second, plot the estimated derivative with the specified perturbation
        estimated_derivative = ((x + perturbation) ** 4 - x ** 4) / perturbation
        plot.extend(plt.plot(estimated_derivative, x_range, show=False,
                             label=f'Estimated dy/dx \n with δ={perturbation}'))
    plot.legend = True
    plot.show()


if __name__ == '__main__':
    dy_over_dx = i()
    print("The derivative of y=x^4 is: " + str(dy_over_dx))
    ii(0.01, sp.symbols('x'), dy_over_dx)
    iii([0.001, 0.01, 0.1, 1], sp.symbols('x'), dy_over_dx)
